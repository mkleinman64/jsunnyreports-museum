Installation: http://www.jsunnyreports.com/index.php/configuration/jsunnyreports/installation/ 

Configuration: http://www.jsunnyreports.com/index.php/configuration/jsunnyreports/configure/

