package nl.mk.jsunnyreports.interfaces;

public interface LoaderInterface {

   void dataLoader( boolean init, Integer year );

  
}



