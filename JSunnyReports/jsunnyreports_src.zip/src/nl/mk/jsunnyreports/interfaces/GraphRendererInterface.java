package nl.mk.jsunnyreports.interfaces;

public interface GraphRendererInterface {
    
    void doMagic();
}


