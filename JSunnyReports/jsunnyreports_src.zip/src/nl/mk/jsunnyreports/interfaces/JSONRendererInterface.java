package nl.mk.jsunnyreports.interfaces;

public interface JSONRendererInterface {
    
    void doMagic();
}


