package nl.mk.jsunnyreports.loaders.inverterdataloaders.processors;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;

import nl.mk.jsunnyreports.common.Constants;
import nl.mk.jsunnyreports.common.settings.Settings;
import nl.mk.jsunnyreports.dataobjects.cache.FileCache;
import nl.mk.jsunnyreports.dataobjects.inverterdata.InverterData;
import nl.mk.jsunnyreports.inverters.OK4EInverter;


import org.apache.log4j.Logger;

public class OK4EFileProcessor extends BaseProcessor  implements Runnable {

    private static final Logger log = Logger.getLogger(OK4EFileProcessor.class);

    public OK4EFileProcessor(File theFile, InverterData inverterData, OK4EInverter ok4eInverter, Settings settings, boolean init, Integer year, FileCache fc ) {
        this.theFile = theFile;
        this.inverterData = inverterData;
        this.ok4eInverter = ok4eInverter;
        this.settings = settings;
        this.init = init;
        this.year = year;
        this.fc = fc;
    }

    private OK4EInverter ok4eInverter;



    public void run() {
        inverterData.setUpdated(true);

        int serialNumber = ok4eInverter.getM_SerialNumber();
        int lineNumber = 0;

        DateFormat formatter;
        formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        formatter.setTimeZone(Constants.getLocalTimeZone());


        /* used for averaging one minute of data */
        int averageMinute = 0;
        float averagePac = 0;
        int entries = 0;

        /* used for calcing and averaging */
        int workMinute = 0;

        String date = "";
        String time = "";
        String Pac = "";
        String serialNo = "";
        int serial;

        //D [d-mm-yyyy];t [hh:mm];sn;E [Wh];Pac [W];Vac [V];Iac [A];Vdc [V];T [C]
        //24-05-2010;12:54;046091;730353;54;224;0.213;31.5;28.5

        try {
            CSVReader reader = new CSVReader(new FileReader(theFile), ';', CSVWriter.NO_QUOTE_CHARACTER, 1);
            String[] nextLine;

            while ((nextLine = reader.readNext()) != null) {
                lineNumber++;
                serialNo = nextLine[2];
                serial = new Integer(serialNo).intValue();

                if (serial == serialNumber) {
                    Pac = nextLine[4];

                    if (!Pac.equals("no read")) {
                        date = nextLine[0];
                        time = nextLine[1];

                        try {
                            Calendar cal = Calendar.getInstance(Constants.getLocalTimeZone());
                            cal.setTime(formatter.parse(date + " " + time));
                            
                            if ( init ) {
                                inverterData.addInitYearSet( cal );    
                            } else {
                                // determining the minute in the day.
                                workMinute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);

                                averagePac = averagePac + Float.valueOf(Pac).floatValue();
                                entries++;

                                // interval threshold is reached. save the data and start with next set.
                                if (workMinute >= (averageMinute + settings.getTimeInterval())) {

                                    float avgPac = (averagePac / entries);
                                    boolean added = inverterData.addWattEntryForInverter(cal.get( Calendar.YEAR), cal.get( Calendar.MONTH ) + 1, cal.get( Calendar.DAY_OF_MONTH), cal.get( Calendar.HOUR_OF_DAY ), cal.get( Calendar.MINUTE ), cal.get( Calendar.SECOND ), ok4eInverter, avgPac, year );
                                    if ( added ) {
                                        fc.setProcessed(true);
                                    }

                                    // finalize for the next interval
                                    averageMinute = workMinute;
                                    averagePac = 0f;
                                    entries = 0;
                                }
                                
                            }

                        } catch (ParseException pe) {
                            log.error("ParseException on line: " + lineNumber + ". I cannot process \"" + date + " " + time + "\" as a correct date. ");
                        }

                    }
                }
            }

        } catch (FileNotFoundException fnfe) {
            log.error("Somehow the file " + theFile.getName() + " could not be found anymore, ignoring it.");
        } catch (IOException IOe) {
            log.error("An error has occured reading line: " + lineNumber + " in file: " + theFile.getName());
        }


    }


}
