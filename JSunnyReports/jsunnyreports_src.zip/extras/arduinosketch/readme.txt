------------------------------------------------------------------------------------------------------------------------------------
software: Arduino sketch version 1.0.0.0
date: 21-01-2012
------------------------------------------------------------------------------------------------------------------------------------

Contents:

- What
- Intended audience
- Directory contents
- Usage
- Sketch
- Credits

::WHAT::
This is the Arduino sketch that will convert the digital signals from the S0 meter into a signal put onto the comport.

::INTENDED AUDIENCE::
You will need some programming skills to use this program. The current code is specific for my own situation so you will need to tailor it a bit for your own needs.

::DIRECTORY CONTENTS::
readme.txt
steca_en_gridfit_logger.pde 			The sketch

::USAGE::
Simply upload the sketch to your Arduino.

::SKETCH::
I hope the code explains itself.


::CREDITS::
Original sketch was written by Rob Tillaart, it was optimized and modified by me.
	
			  
			  
			  
 
