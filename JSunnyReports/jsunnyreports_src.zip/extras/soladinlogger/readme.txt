------------------------------------------------------------------------------------------------------------------------------------
software: Soladinlogger 1.0.0.0
date: 21-01-2012
------------------------------------------------------------------------------------------------------------------------------------

Contents:

- What
- Intended audience
- Directory contents
- Usage
- Credits

::WHAT::
This is the soladin logger which can be used in conjunction with jSunnyreports.

::INTENDED AUDIENCE::
Anyone with a Soladin 600 and a RS485 -- RS232 converter connected to a computer.

::DIRECTORY CONTENTS::
readme.txt
WinSoladinLogger.exe                Main executable

::USAGE::
Make sure you have .NET 4.0 installed! location: http://www.microsoft.com/download/en/details.aspx?id=17851

Run WinSoladinLogger.exe 

1. select the right comport
2. open the comport
3. set the correct logfile location and make sure it is ended with a "\".
4. test is by using the B6 command button ( ReadB6 ). It should give you some info on your inverter in the fields in the bottom of the program.
5. press "start" button

::CREDITS::
(c) 2010 - 2012 Martin Kleinman, the sourcecode can be downloaded from www.jsunnyreports.com	
			  
			  
			