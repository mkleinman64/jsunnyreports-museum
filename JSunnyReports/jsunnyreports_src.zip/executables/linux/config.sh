#!/bin/bash
java -jar JSunnyReports.jar -config
